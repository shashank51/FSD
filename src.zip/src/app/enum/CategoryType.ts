export enum CategoryType {
    "Books", "Food",  "Clothing","Electronics","Sports","Stationery"
}
